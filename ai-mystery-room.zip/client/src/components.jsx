export function Spinner({ label = "Loading…" }) {
  return (
    <div role="status" className="flex items-center gap-3 text-muted py-10">
      <span className="h-5 w-5 rounded-full border-2 border-line border-t-tag animate-spin" />
      <span>{label}</span>
    </div>
  );
}

export function ErrorBox({ message, onRetry }) {
  if (!message) return null;
  return (
    <div role="alert" className="border border-string bg-string/10 rounded px-4 py-3 my-4">
      <p>{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="mt-2 underline text-tag">
          Try again
        </button>
      )}
    </div>
  );
}

export const btnPrimary =
  "inline-block bg-string text-white font-semibold px-5 py-2.5 rounded hover:bg-string/85 transition-colors disabled:opacity-50 disabled:cursor-not-allowed";
export const btnGhost =
  "inline-block border border-line text-paper px-4 py-2 rounded hover:border-tag transition-colors disabled:opacity-50 disabled:cursor-not-allowed";

export const DIFFICULTY = {
  easy: { label: "Easy", blurb: "3 suspects · 5 clues · 2 hints", base: 100 },
  medium: { label: "Medium", blurb: "4 suspects · 7 clues · 3 hints", base: 150 },
  hard: { label: "Hard", blurb: "5 suspects · 9 clues · 3 hints", base: 200 },
};
