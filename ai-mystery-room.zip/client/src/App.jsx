import { Link, Route, Routes } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Create from "./pages/Create.jsx";
import Investigation from "./pages/Investigation.jsx";
import Accusation from "./pages/Accusation.jsx";
import Results from "./pages/Results.jsx";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-line">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="font-display text-xl text-tag">
            AI Mystery Room
          </Link>
          <Link to="/create" className="text-muted hover:text-paper text-sm">
            New mystery
          </Link>
        </div>
      </header>
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/create" element={<Create />} />
          <Route path="/case/:id" element={<Investigation />} />
          <Route path="/case/:id/accuse" element={<Accusation />} />
          <Route path="/case/:id/result" element={<Results />} />
          <Route
            path="*"
            element={
              <div>
                <h1 className="font-display text-3xl mb-3">Page not found</h1>
                <Link to="/" className="text-tag underline">Back to the start</Link>
              </div>
            }
          />
        </Routes>
      </main>
    </div>
  );
}
