import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { discoverClue, errMsg, getCase, requestHint } from "../api.js";
import { btnGhost, btnPrimary, DIFFICULTY, ErrorBox, Spinner } from "../components.jsx";

export default function Investigation() {
  const { id } = useParams();
  const nav = useNavigate();
  const [c, setC] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const data = await getCase(id);
      if (data.status === "completed") return nav(`/case/${id}/result`, { replace: true });
      setC(data);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [id, nav]);

  useEffect(() => { load(); }, [load]);

  async function act(fn) {
    setBusy(true);
    setError("");
    try {
      setC(await fn());
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <Spinner label="Opening case file…" />;
  if (!c) return <ErrorBox message={error || "Case not found."} onRetry={load} />;

  const p = c.progress;
  const hintsLeft = p.hintsTotal - p.hintsUsed;

  return (
    <div>
      <div className="flex flex-wrap items-baseline gap-3 mb-1">
        <h1 className="font-display text-3xl sm:text-4xl">{c.title}</h1>
        <span className="text-xs border border-line rounded px-2 py-0.5 text-muted">{DIFFICULTY[c.difficulty].label}</span>
      </div>

      <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-muted mb-6" aria-label="Progress">
        <span>Clues found: <b className="text-tag">{p.cluesFound}/{p.cluesTotal}</b></span>
        <span>Hints used: <b className="text-tag">{p.hintsUsed}/{p.hintsTotal}</b></span>
      </div>

      <ErrorBox message={error} />

      <p className="max-w-prose whitespace-pre-line mb-10">{c.story}</p>

      <section className="mb-10">
        <h2 className="font-display text-2xl mb-3">Suspects</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {c.suspects.map((s) => (
            <article key={s.id} className="bg-board border border-line border-t-4 border-t-muted rounded-b p-4">
              <h3 className="font-semibold text-lg">{s.name}</h3>
              <p className="text-tag text-sm mb-2">{s.role}</p>
              <p className="text-sm mb-2">{s.description}</p>
              <p className="text-sm text-muted"><b>Alibi:</b> {s.alibi}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="font-display text-2xl mb-3">Evidence</h2>
        <ul className="grid gap-3 sm:grid-cols-2">
          {c.clues.map((cl) => (
            <li key={cl.id} className={`rounded p-4 border ${cl.discovered ? "border-tag bg-board" : "border-dashed border-line"}`}>
              <h3 className="font-semibold">{cl.title}</h3>
              {cl.discovered ? (
                <p className="text-sm mt-1">{cl.description}</p>
              ) : (
                <button disabled={busy} onClick={() => act(() => discoverClue(id, cl.id))} className={`${btnGhost} mt-2 text-sm`}>
                  Examine
                </button>
              )}
            </li>
          ))}
        </ul>
      </section>

      <section className="mb-10">
        <h2 className="font-display text-2xl mb-3">Hints</h2>
        {c.hints.length === 0 && <p className="text-muted text-sm mb-3">No hints used yet.</p>}
        <ol className="list-decimal pl-5 space-y-2 mb-3">
          {c.hints.map((h, i) => <li key={i}>{h}</li>)}
        </ol>
        <button disabled={busy || hintsLeft === 0} onClick={() => act(() => requestHint(id))} className={btnGhost}>
          {hintsLeft === 0 ? "No hints left" : `Get a hint (−10 points, ${hintsLeft} left)`}
        </button>
      </section>

      <div className="border-t border-line pt-6">
        <p className="text-muted text-sm mb-3">Ready? You only get one accusation.</p>
        <Link to={`/case/${id}/accuse`} className={btnPrimary}>Make an accusation</Link>
      </div>
    </div>
  );
}
