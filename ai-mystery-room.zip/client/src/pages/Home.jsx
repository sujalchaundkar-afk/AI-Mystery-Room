import { Link } from "react-router-dom";
import { btnPrimary } from "../components.jsx";

export default function Home() {
  return (
    <section className="max-w-2xl py-8">
      <p className="font-display text-string text-lg mb-2">Case file No. 0001</p>
      <h1 className="font-display text-4xl sm:text-6xl leading-tight mb-6">
        Someone in this room is lying.
      </h1>
      <p className="text-muted text-lg mb-8 max-w-prose">
        Describe a setting and Gemini writes you a fresh mystery: suspects with alibis, evidence to examine, and a culprit
        hidden until you name them. Collect clues, use hints if you must, then make your accusation.
      </p>
      <Link to="/create" className={btnPrimary}>
        Open a new case
      </Link>

      <ul className="mt-12 grid gap-4 sm:grid-cols-3 text-sm">
        <li className="border-l-2 border-tag pl-3">
          <b className="block text-paper">Investigate</b>
          <span className="text-muted">Each clue you find is worth +5 points.</span>
        </li>
        <li className="border-l-2 border-tag pl-3">
          <b className="block text-paper">Ask for hints</b>
          <span className="text-muted">Hints help, but each one costs 10 points.</span>
        </li>
        <li className="border-l-2 border-tag pl-3">
          <b className="block text-paper">Accuse</b>
          <span className="text-muted">You get one accusation per case, so choose carefully.</span>
        </li>
      </ul>
    </section>
  );
}
