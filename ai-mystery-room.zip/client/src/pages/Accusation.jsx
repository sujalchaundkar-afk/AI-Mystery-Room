import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { accuse, errMsg, getCase } from "../api.js";
import { btnGhost, btnPrimary, ErrorBox, Spinner } from "../components.jsx";

export default function Accusation() {
  const { id } = useParams();
  const nav = useNavigate();
  const [c, setC] = useState(null);
  const [picked, setPicked] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    getCase(id)
      .then((d) => (d.status === "completed" ? nav(`/case/${id}/result`, { replace: true }) : setC(d)))
      .catch((e) => setError(errMsg(e)))
      .finally(() => setLoading(false));
  }, [id, nav]);

  async function submit() {
    setSending(true);
    setError("");
    try {
      await accuse(id, picked);
      nav(`/case/${id}/result`);
    } catch (e) {
      setError(errMsg(e));
      setSending(false);
    }
  }

  if (loading) return <Spinner />;
  if (!c) return <ErrorBox message={error || "Case not found."} />;

  return (
    <div className="max-w-2xl">
      <h1 className="font-display text-3xl mb-1">Who did it?</h1>
      <p className="text-muted mb-6">{c.title}. This choice is final.</p>

      <fieldset>
        <legend className="sr-only">Choose a suspect</legend>
        <div className="space-y-3">
          {c.suspects.map((s) => (
            <label key={s.id} className={`flex gap-3 items-start cursor-pointer border rounded p-4 ${picked === s.id ? "border-string bg-board" : "border-line"}`}>
              <input type="radio" name="suspect" value={s.id} checked={picked === s.id} onChange={() => setPicked(s.id)} className="mt-1.5 accent-[#e0524d]" />
              <span>
                <b className="block">{s.name}</b>
                <span className="text-tag text-sm">{s.role}</span>
              </span>
            </label>
          ))}
        </div>
      </fieldset>

      <ErrorBox message={error} />

      <div className="flex gap-3 mt-6">
        <button disabled={!picked || sending} onClick={submit} className={btnPrimary}>
          {sending ? "Submitting…" : "Accuse this suspect"}
        </button>
        <Link to={`/case/${id}`} className={btnGhost}>Back to investigation</Link>
      </div>
    </div>
  );
}
