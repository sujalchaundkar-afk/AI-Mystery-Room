import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createCase, errMsg } from "../api.js";
import { btnPrimary, DIFFICULTY, ErrorBox, Spinner } from "../components.jsx";

const IDEAS = [
  "A jewel theft at a mountain ski lodge during a blizzard",
  "A poisoned cup of tea at a village bake-off",
  "A missing painting aboard a luxury night train",
];

export default function Create() {
  const nav = useNavigate();
  const [premise, setPremise] = useState("");
  const [difficulty, setDifficulty] = useState("easy");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const tooShort = premise.trim().length < 10;

  async function submit(e) {
    e.preventDefault();
    if (tooShort || loading) return;
    setLoading(true);
    setError("");
    try {
      const c = await createCase(premise.trim(), difficulty);
      nav(`/case/${c.id}`);
    } catch (err) {
      setError(errMsg(err));
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="max-w-xl">
        <h1 className="font-display text-3xl mb-2">Writing your case…</h1>
        <p className="text-muted">Gemini is placing the suspects and hiding the evidence. This can take up to 30 seconds.</p>
        <Spinner label="Generating mystery" />
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="max-w-xl">
      <h1 className="font-display text-3xl mb-6">Open a new case</h1>

      <label htmlFor="premise" className="block font-semibold mb-1">Premise</label>
      <textarea
        id="premise"
        value={premise}
        onChange={(e) => setPremise(e.target.value)}
        maxLength={300}
        rows={4}
        placeholder="Where does it happen, and what went wrong?"
        className="w-full bg-board border border-line rounded p-3 focus:border-tag"
      />
      <div className="flex justify-between text-xs text-muted mt-1">
        <span>10–300 characters</span>
        <span>{premise.length}/300</span>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        {IDEAS.map((i) => (
          <button type="button" key={i} onClick={() => setPremise(i)} className="text-xs border border-line rounded-full px-3 py-1 text-muted hover:text-paper hover:border-tag">
            {i}
          </button>
        ))}
      </div>

      <fieldset className="mt-8">
        <legend className="font-semibold mb-2">Difficulty</legend>
        <div className="grid gap-3 sm:grid-cols-3">
          {Object.entries(DIFFICULTY).map(([key, d]) => (
            <label
              key={key}
              className={`cursor-pointer border rounded p-3 ${difficulty === key ? "border-tag bg-board" : "border-line"}`}
            >
              <input type="radio" name="difficulty" value={key} checked={difficulty === key} onChange={() => setDifficulty(key)} className="sr-only" />
              <span className="block font-semibold">{d.label}</span>
              <span className="block text-xs text-muted">{d.blurb}</span>
              <span className="block text-xs text-tag mt-1">{d.base} points for a correct accusation</span>
            </label>
          ))}
        </div>
      </fieldset>

      <ErrorBox message={error} />

      <button type="submit" disabled={tooShort} className={`${btnPrimary} mt-6`}>
        Generate mystery
      </button>
    </form>
  );
}
