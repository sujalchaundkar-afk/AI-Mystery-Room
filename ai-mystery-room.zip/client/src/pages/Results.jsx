import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { errMsg, getResult } from "../api.js";
import { btnGhost, btnPrimary, DIFFICULTY, ErrorBox, Spinner } from "../components.jsx";

export default function Results() {
  const { id } = useParams();
  const [r, setR] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getResult(id).then(setR).catch((e) => setError(errMsg(e)));
  }, [id]);

  if (error) {
    return (
      <div>
        <ErrorBox message={error} />
        <Link to={`/case/${id}`} className={btnGhost}>Back to the case</Link>
      </div>
    );
  }
  if (!r) return <Spinner label="Reading the verdict…" />;

  const accused = r.suspects.find((s) => s.id === r.accusedId);
  const b = r.breakdown;

  return (
    <div className="max-w-2xl">
      <p className={`font-display text-lg ${r.correct ? "text-tag" : "text-string"}`}>
        {r.correct ? "Case closed." : "Wrong suspect."}
      </p>
      <h1 className="font-display text-4xl mb-2">
        {r.correct ? "You found the culprit." : "The culprit got away."}
      </h1>
      <p className="text-muted mb-6">
        {r.title} · {DIFFICULTY[r.difficulty].label} · You accused {accused?.name}
      </p>

      <div className="bg-board border border-line rounded p-5 mb-6">
        <p className="text-sm text-muted">Final score</p>
        <p className="font-display text-5xl text-tag">{r.score}</p>
        <dl className="mt-3 text-sm grid grid-cols-[1fr_auto] gap-x-6 gap-y-1 max-w-xs">
          <dt>Correct accusation</dt><dd>+{b.base}</dd>
          <dt>Clues found ({r.progress.cluesFound})</dt><dd>+{b.clues}</dd>
          <dt>Hints used ({r.progress.hintsUsed})</dt><dd>−{b.hints}</dd>
        </dl>
      </div>

      <section className="mb-6">
        <h2 className="font-display text-2xl mb-1">The culprit: {r.culprit.name}</h2>
        <p className="text-tag text-sm mb-2">{r.culprit.role}</p>
        <p className="whitespace-pre-line">{r.solution}</p>
      </section>

      <section className="mb-8">
        <h2 className="font-display text-2xl mb-2">All the evidence</h2>
        <ul className="space-y-2 text-sm">
          {r.clues.map((c) => (
            <li key={c.id} className={c.discovered ? "" : "text-muted"}>
              <b>{c.title}</b>{!c.discovered && " (not examined)"}: {c.description}
            </li>
          ))}
        </ul>
      </section>

      <Link to="/create" className={btnPrimary}>Start another mystery</Link>
    </div>
  );
}
