import "dotenv/config";
import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import casesRouter from "./routes/cases.js";

const app = express();
const origins = (process.env.CLIENT_URL || "http://localhost:5173")
  .split(",")
  .map((s) => s.trim().replace(/\/$/, ""));

app.use(cors({ origin: origins }));
app.use(express.json({ limit: "20kb" }));

app.get("/api/health", (_req, res) => res.json({ ok: true }));
app.use("/api/cases", casesRouter);

app.use((_req, res) => res.status(404).json({ error: "Route not found." }));

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.expose ? err.message : "Something went wrong on the server." });
});

const PORT = process.env.PORT || 5000;

async function start() {
  if (!process.env.MONGODB_URI) throw new Error("MONGODB_URI is missing in .env");
  if (!process.env.GEMINI_API_KEY) throw new Error("GEMINI_API_KEY is missing in .env");
  await mongoose.connect(process.env.MONGODB_URI);
  console.log("MongoDB connected");
  app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
}

start().catch((e) => {
  console.error("Failed to start:", e.message);
  process.exit(1);
});
