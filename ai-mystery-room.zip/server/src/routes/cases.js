import { Router } from "express";
import mongoose from "mongoose";
import { z } from "zod";
import Case from "../models/Case.js";
import { generateMystery, RULES } from "../services/gemini.js";

const router = Router();

const httpError = (status, message) => Object.assign(new Error(message), { status, expose: true });
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);

const createSchema = z.object({
  premise: z.string().trim().min(10, "Premise must be at least 10 characters.").max(300, "Premise must be 300 characters or fewer."),
  difficulty: z.enum(["easy", "medium", "hard"], { message: "Difficulty must be easy, medium or hard." }),
});

export function computeScore({ difficulty, correct, cluesFound, hintsUsed }) {
  const base = correct ? RULES[difficulty].base : 0;
  const clues = cluesFound * 5;
  const hints = hintsUsed * 10;
  return { base, clues, hints, score: Math.max(0, base + clues - hints) };
}

const stats = (c) => ({
  cluesFound: c.clues.filter((x) => x.discovered).length,
  cluesTotal: c.clues.length,
  hintsUsed: c.hints.filter((h) => h.used).length,
  hintsTotal: c.hints.length,
});

// Public view: the culprit and solution are never included here.
function toPublic(c) {
  return {
    id: c._id,
    title: c.title,
    story: c.story,
    premise: c.premise,
    difficulty: c.difficulty,
    status: c.status,
    suspects: c.suspects.map((s) => ({ id: s.key, name: s.name, role: s.role, description: s.description, alibi: s.alibi })),
    clues: c.clues.map((x) => ({
      id: x.key,
      title: x.title,
      discovered: x.discovered,
      description: x.discovered ? x.description : null,
    })),
    hints: c.hints.filter((h) => h.used).map((h) => h.text),
    progress: stats(c),
  };
}

async function loadCase(id) {
  if (!mongoose.isValidObjectId(id)) throw httpError(400, "Invalid case id.");
  const c = await Case.findById(id);
  if (!c) throw httpError(404, "Case not found.");
  return c;
}

// POST /api/cases — generate a mystery
router.post(
  "/",
  wrap(async (req, res) => {
    const parsed = createSchema.safeParse(req.body);
    if (!parsed.success) throw httpError(400, parsed.error.issues[0].message);
    const { premise, difficulty } = parsed.data;

    const m = await generateMystery(premise, difficulty);
    const suspects = m.suspects.map((s, i) => ({ key: `s${i + 1}`, ...s }));
    const doc = await Case.create({
      title: m.title,
      story: m.story,
      premise,
      difficulty,
      suspects,
      clues: m.clues.map((c, i) => ({ key: `c${i + 1}`, ...c })),
      hints: m.hints.map((text) => ({ text })),
      culpritKey: suspects[m.culpritIndex].key,
      solution: m.solution,
    });
    res.status(201).json(toPublic(doc));
  })
);

// GET /api/cases/:id — active case (no secrets)
router.get(
  "/:id",
  wrap(async (req, res) => {
    res.json(toPublic(await loadCase(req.params.id)));
  })
);

// POST /api/cases/:id/clues/:clueId/discover
router.post(
  "/:id/clues/:clueId/discover",
  wrap(async (req, res) => {
    const c = await loadCase(req.params.id);
    if (c.status === "completed") throw httpError(409, "This case is already closed.");
    const clue = c.clues.find((x) => x.key === req.params.clueId);
    if (!clue) throw httpError(404, "Clue not found.");
    clue.discovered = true; // idempotent
    await c.save();
    res.json(toPublic(c));
  })
);

// POST /api/cases/:id/hints — reveal the next hint
router.post(
  "/:id/hints",
  wrap(async (req, res) => {
    const c = await loadCase(req.params.id);
    if (c.status === "completed") throw httpError(409, "This case is already closed.");
    const next = c.hints.find((h) => !h.used);
    if (!next) throw httpError(400, "No hints left for this case.");
    next.used = true;
    await c.save();
    res.json({ ...toPublic(c), newHint: next.text });
  })
);

// POST /api/cases/:id/accuse
router.post(
  "/:id/accuse",
  wrap(async (req, res) => {
    const { suspectId } = req.body || {};
    const c = await loadCase(req.params.id);
    if (c.status === "completed") throw httpError(409, "This case is already closed.");
    if (typeof suspectId !== "string" || !c.suspects.some((s) => s.key === suspectId)) {
      throw httpError(400, "Choose one of the listed suspects.");
    }

    const correct = suspectId === c.culpritKey;
    const { cluesFound, hintsUsed } = stats(c);
    const { base, clues, hints, score } = computeScore({ difficulty: c.difficulty, correct, cluesFound, hintsUsed });

    c.status = "completed";
    c.accusedKey = suspectId;
    c.correct = correct;
    c.score = score;
    c.breakdown = { base, clues, hints };
    await c.save();

    res.json({ correct, score });
  })
);

// GET /api/cases/:id/result — only after the accusation
router.get(
  "/:id/result",
  wrap(async (req, res) => {
    const c = await loadCase(req.params.id);
    if (c.status !== "completed") throw httpError(403, "The result is locked until you make an accusation.");
    const culprit = c.suspects.find((s) => s.key === c.culpritKey);
    res.json({
      id: c._id,
      title: c.title,
      difficulty: c.difficulty,
      correct: c.correct,
      accusedId: c.accusedKey,
      culprit: { id: culprit.key, name: culprit.name, role: culprit.role },
      solution: c.solution,
      score: c.score,
      breakdown: c.breakdown,
      progress: stats(c),
      suspects: c.suspects.map((s) => ({ id: s.key, name: s.name, role: s.role })),
      clues: c.clues.map((x) => ({ id: x.key, title: x.title, description: x.description, discovered: x.discovered })),
    });
  })
);

export default router;
