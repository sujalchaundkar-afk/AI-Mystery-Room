import mongoose from "mongoose";

const { Schema } = mongoose;

const caseSchema = new Schema(
  {
    title: { type: String, required: true },
    story: { type: String, required: true },
    premise: { type: String, required: true },
    difficulty: { type: String, enum: ["easy", "medium", "hard"], required: true },

    suspects: [
      {
        _id: false,
        key: String,
        name: String,
        role: String,
        description: String,
        alibi: String,
      },
    ],
    clues: [
      {
        _id: false,
        key: String,
        title: String,
        description: String,
        discovered: { type: Boolean, default: false },
      },
    ],
    hints: [{ _id: false, text: String, used: { type: Boolean, default: false } }],

    // Secret: never sent to the client before the case is completed
    culpritKey: { type: String, required: true },
    solution: { type: String, required: true },

    // Player progress
    status: { type: String, enum: ["active", "completed"], default: "active" },
    accusedKey: String,
    correct: Boolean,
    score: Number,
    breakdown: { base: Number, clues: Number, hints: Number },
  },
  { timestamps: true }
);

export default mongoose.model("Case", caseSchema);
